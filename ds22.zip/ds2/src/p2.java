import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JTable;
import java.sql.ResultSet;
import javax.swing.JScrollPane;
public class p2 extends JFrame {
    private JPanel panel2;
    private JTable table2;
    private JButton chercherButton;
    private JScrollPane table_2;

    private JTextField em;

    private JTextField sp;
    private JButton ajouter;




    private JButton supprimer;
    private JButton modifier;
    private JCheckBox concep;
    private JCheckBox bdd;
    private JCheckBox jav;
    private JCheckBox wb;
    private JButton consulter;
    private JButton consulterButton;

    public JPanel getpanel() {
        return panel2;
    }

    public p2() {
        super("p2");
        table2();




        ajouter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = em.getText();
                boolean java= jav.isSelected();
                boolean conception = concep.isSelected();
                boolean bd = bdd.isSelected();
                boolean web = wb.isSelected();
                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";
                try {
                    Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement stmt = conn.createStatement();
                    String sql = "INSERT INTO cours (email, java, conception,bd, web) " +
                            "VALUES (?, ?, ?, ? , ?)";
                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.setString(1,email );
                    preparedStatement.setBoolean(2,java);
                    preparedStatement.setBoolean(3,conception);
                    preparedStatement.setBoolean(4,bd);
                    preparedStatement.setBoolean(5,web);

                    preparedStatement.executeUpdate();
                  {








                    }

                    table2();
                    stmt.close();
                    conn.close();


                } catch (Exception e1) {
                    System.out.println("Erreur lors de l'insertion des données : " + e1.getMessage());
                }
            }
        });
        supprimer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                { String email = em.getText();




                    String spp;
                    spp=sp.getText();


                    final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                    final String USERNAME = "root";
                    final String PASSWORD = "";
                    try {
                        Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                        Statement stmt = conn.createStatement();
                        String sql = "delete from cours  " +
                                "where email=?";

                        PreparedStatement preparedStatement = conn.prepareStatement(sql);
                        preparedStatement.setString(1, spp);

                        {



                            preparedStatement.executeUpdate();





                        }


                        table2();
                        stmt.close();
                        conn.close();


                    } catch (Exception e1) {
                        System.out.println("Erreur lors de la supprision des données : " + e1.getMessage());

                    }
                }

            }
        });
        modifier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = em.getText();
                boolean java= jav.isSelected();
                boolean conception = concep.isSelected();
                boolean bd = bdd.isSelected();
                boolean web = wb.isSelected();

                String rec;
                rec=sp.getText();


                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";
                try {



                    Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);


                    PreparedStatement stmt = conn.prepareStatement("update cours Set java=?,conception=?,bd=?,web=?  where email=?");

                    stmt.setBoolean(1,java);
                    stmt.setBoolean(2,conception);
                    stmt.setBoolean(3,bd);
                    stmt.setBoolean(4,web);
                    stmt.setString(5,rec);
                    stmt.executeUpdate();






                    int rowsUpdated = stmt.executeUpdate();
                    {   if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(null, "Mise à jour réussie");
                    } else {
                        JOptionPane.showMessageDialog(null, "Aucune mise à jour effectuée");
                    }


















                    }

                    table2();
                    stmt.close();
                    conn.close();


                } catch (Exception e5) {
                    System.out.println("Erreur lors de la mise a jour des données : " + e5.getMessage());

                }

            }
        });
        consulter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame1 = new JFrame("p1");
                getContentPane().add(consulter, BorderLayout.CENTER);
                frame1.setContentPane(new gerer().getpanel());
                frame1.pack();
                frame1.setVisible(true);

            }
        });

    }





        private void table2() {


        try {
                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";

                Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM  cours");
                table2.setModel(DbUtils.resultSetToTableModel(rs));






            } catch (SQLException e4) {
                throw new RuntimeException(e4);
            }


        }
    }
