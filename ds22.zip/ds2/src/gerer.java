import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class gerer extends JFrame {
    private JPanel p3;
    private JTextField nj;
    private JTextField nc;
    private JTextField nw;
    private JTable table3;
    private JScrollPane tab;
    private JTextField nbd;
    private JButton ajouterButton;
    private JButton modifierButton;
    private JTextField em;

    public JPanel getpanel() {  return p3;}




    public gerer() {
        super("p3");
        table3();


        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Double notej = Double.valueOf(nj.getText());
                Double notec = Double.valueOf(nc.getText());
                Double noteb = Double.valueOf(nbd.getText());
                Double notew= Double.valueOf(nw.getText());
                String email = em.getText();


                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";

                try {

                    Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement stmt = conn.createStatement();
                    String sql = "INSERT INTO note (notej,notec ,noteb, notew,email) " +
                            "VALUES (?, ?, ?, ?,?)";

                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.setDouble(1,notej );
                    preparedStatement.setDouble(2,notec );
                    preparedStatement.setDouble(3,noteb );
                    preparedStatement.setDouble(4,notew );
                    preparedStatement.setString(5,email );
                    preparedStatement.setString(5, email);



                    boolean java = false;
                    boolean conception = false;
                    boolean bd = false;
                    boolean web = false;





                    int addedRows = preparedStatement.executeUpdate();
                    if (addedRows > 0 ) {



                    }

                    table3();
                    stmt.close();
                    conn.close();


                } catch (Exception e1) {
                    System.out.println("Erreur lors de l'insertion des données : " + e1.getMessage());
                }
            }

        });
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String email = em.getText();





                String cal;
                cal=em.getText();


                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";
                try {
                    Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                    Statement stmt = conn.prepareStatement("select avg(notej),avg(notec),avg(noteb),avg(notew) from note  " +
                            "where email=?");
                   



                    {












                    }


                    table3();
                    stmt.close();
                    conn.close();


                } catch (Exception e1) {
                    System.out.println("Erreur lors de la calcule des données : " + e1.getMessage());

                }
            }


    });
}



    private void table3() {
           try {
                final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

                final String USERNAME = "root";
                final String PASSWORD = "";

                Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM note");
                table3.setModel(DbUtils.resultSetToTableModel(rs));
           } catch (SQLException e4) {
               throw new RuntimeException(e4);
           }


    }










    }












